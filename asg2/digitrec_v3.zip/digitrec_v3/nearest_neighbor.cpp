#include "typedefs.h"
#include "nearest_neighbor.h"
#include <stdio.h>

#define N 2000

void nearest_neighbor(digit &input, bit4 &nearest) {

  // Include the training data stored in a two-dimensional array
  #include "training_data.h"

  // Insert code here (if needed)

  for (unsigned int data = 0; data < N; data++) { 

    // Write your k-NN core here
  
    for (int possible_result = 0; possible_result < 10; possible_result++) {
    
      // Insert code here (if needed)
    


    }
  
  }  
  
  // Insert code here (if needed)

}

void find_difference(digit &input, const digit &data, bit6 &difference) {

  // Insert code here (if needed)

}

void count_set_bits(digit count_this, bit6 &difference) {

  // Insert code here (if needed)

}
